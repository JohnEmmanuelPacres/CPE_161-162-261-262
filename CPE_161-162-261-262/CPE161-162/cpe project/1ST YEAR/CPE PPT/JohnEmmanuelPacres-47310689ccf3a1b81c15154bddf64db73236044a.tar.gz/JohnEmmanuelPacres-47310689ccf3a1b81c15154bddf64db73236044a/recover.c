#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#define jpeg_block 512

typedef uint8_t BYTE;

int main(int argc, char *argv[])
{
    // accept one line argument
    if (argc != 2)
    {
        printf("Usage: ./recover FILE\n");
        return 1;
    }

    // open the memory card
    FILE *memory_card = fopen(argv[1], "r");
    if (memory_card == NULL)
    {
        printf("File not found. Please try again...\n");
        return 1;
    }

    // variable declaration, allocate memory, buffer..
    bool found_jpeg = false;
    int jpeg_count = 0;
    BYTE buffer[jpeg_block];
    char file_name[8];
    FILE *jpegFile = NULL;

    // while there is still memory left in memory card, read..
    while (fread(buffer, jpeg_block, 1, memory_card) == 1)
    {
        // create jpegs from data
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {
            if (found_jpeg)
            {
                fclose(jpegFile);
            }
            else
            {
                found_jpeg = true;
            }

            // print in the string
            sprintf(file_name, "%03i.jpg", jpeg_count);
            jpegFile = fopen(file_name, "w");

            if (jpegFile == NULL)
            {
                fclose(memory_card);
                printf("Error file creation...\n");
                return 3;
            }
            jpeg_count++;
        }
        // check if valid input
        if (found_jpeg)
        {
            fwrite(buffer, jpeg_block, 1, jpegFile);
        }
    }

    // close previous jpeg
    fclose(memory_card);
    if (found_jpeg)
    {
        fclose(jpegFile);
    }
    return 0;
}
